import numpy as np
import matplotlib.pyplot as plt
# NO other imports are allowed

class Shape:
    '''
    DO NOT MODIFY THIS CLASS

    DO NOT ADD ANY NEW METHODS TO THIS CLASS
    '''
    def __init__(self):
        self.T_s = None
        self.T_r = None
        self.T_t = None
    
    
    def translate(self, dx, dy):
        '''
        Polygon and Circle class should use this function to calculate the translation
        '''
        self.T_t = np.array([[1, 0, dx], [0, 1, dy], [0, 0, 1]])
 

    def scale(self, sx, sy):
        '''
        Polygon and Circle class should use this function to calculate the scaling
        '''
        self.T_s = np.array([[sx, 0, 0], [0, sy, 0], [0, 0, 1]])
 
        
    def rotate(self, deg):
        '''
        Polygon and Circle class should use this function to calculate the rotation
        '''
        rad = deg*(np.pi/180)
        self.T_r = np.array([[np.cos(rad), np.sin(rad), 0],[-np.sin(rad), np.cos(rad),0], [0, 0, 1]])

        
    def plot(self, x_dim, y_dim):
        '''
        Polygon and Circle class should use this function while plotting
        x_dim and y_dim should be such that both the figures are visible inside the plot
        '''
        x_dim, y_dim = 1.2*x_dim, 1.2*y_dim
        plt.plot((-x_dim, x_dim),[0,0],'k-')
        plt.plot([0,0],(-y_dim, y_dim),'k-')
        plt.xlim(-x_dim,x_dim)
        plt.ylim(-y_dim,y_dim)
        plt.grid()
        plt.show()



class Polygon(Shape):
    '''
    Object of class Polygon should be created when shape type is 'polygon'
    '''
    def __init__(self, A):
        '''
        Initializations here
        '''

        self.matrix = A # Matrix for storing coordinates of polygon
        self.old_matrix=A # Matrix for storing coordinates of Polgon before the operation was performed
        super().__init__() #Inheriting attributes of class Shape

        
 
    
    def translate(self, dx, dy=None):
        '''
        Function to translate the polygon
    
        This function takes 2 arguments: dx and dy
    
        This function returns the final coordinates
        '''
        if(dy==None):
            dy=dx
        transpose = self.matrix.T                         #Taking transpose of matrix to get coordinates column wise
        Shape.translate(self,dx,dy)                       #Get the translate matrix for translation
        new_coord = np.matmul(self.T_t,transpose)         #Multiply the translate matrix with the matrix of coordinates to get the new coordinates
        final_new_coord=new_coord.T                       #Storing final coordinates and taking transpose
        final_coord_x=[]                                  #Forming lists for final coordinates
        final_coord_y=[]
        for_ones=[]
        for i in range(0,len(final_new_coord)):
            final_coord_x.append(round(final_new_coord[i][0],2))           #Adding x coordinates in list of final x coordinates
            for_ones.append(1)                                             #Adding 1's as the 3x3 matrix of coordinates for Polygons has 1's in the last column
        for i in range (0,len(final_new_coord)):
            final_coord_y.append(round(final_new_coord[i][1],2))           #Adding y coordinates in the list of final y coordinates
        temp_matrix=np.array([final_coord_x,final_coord_y,for_ones])
        self.old_matrix=self.matrix                                       #Replacing previous coordinates with existing ones and then replacing current coordinates with the changed ones
        self.matrix=temp_matrix.T
        return (np.array(final_coord_x),np.array(final_coord_y))


    
    def scale(self, sx, sy=None):
        '''
        Function to scale the polygon
    
        This function takes 2 arguments: sx and sx
    
        This function returns the final coordinates
        '''
        x_centroid=0.0
        y_centroid=0.0
        if(sy==None):
            sy=sx
        for i in range(0,len(self.matrix)):
            x_centroid+=self.matrix[i][0]                  #Finding x coordinate of centroid
        x_centroid=x_centroid/len(self.matrix)
        for i in range(0,len(self.matrix)):
            y_centroid+=self.matrix[i][1]                 #Finding y coordinate of centroid
        y_centroid=y_centroid/len(self.matrix)
        Shape.translate(self,-x_centroid,-y_centroid)    #Translating centroid to origin so translate matrix for that
        Shape.scale(self,sx,sy)                          #Gives scaling matrix
        T1_mul_S = np.matmul(self.T_t.T,self.T_s)        #Multiplying scaling matrix with the translate matrix
        Shape.translate(self,x_centroid,y_centroid)      #Translate back centroid so translate matrix for that
        final_scale=np.matmul(T1_mul_S,self.T_t.T)       #Get the final scaling matrix according to the formula final S= TST
        ans=np.matmul(self.matrix, final_scale)          #Perform scaling and get final coordinates by multiplying final scaling matrix with matrix of coordinates
        self.old_matrix=self.matrix                      #Replacing previous coordinates with existing ones and then replacing current coordinates with the changed ones
        self.matrix=ans
        final_coord_x=[]
        final_coord_y=[]                                #Forming lists for final coordinates
        for i in range(len(self.matrix)):       
            z=round(self.matrix[i][0],2)
            self.matrix[i][0]=z
            final_coord_x.append(z)                     #Returning final coordinates in the given format
        for i in range(len(self.matrix)):
            w=round(self.matrix[i][1],2)
            self.matrix[i][1]=w
            final_coord_y.append(w)

        return(np.array(final_coord_x),np.array(final_coord_y))
 
    
    def rotate(self, deg, rx = 0, ry = 0):
        '''
        Function to rotate the polygon
    
        This function takes 3 arguments: deg, rx(optional), ry(optional). Default rx and ry = 0. (Rotate about origin)
    
        This function returns the final coordinates
        '''
        Shape.translate(self,rx,ry)                      #Translate the point of rotation to origin so translate matrix for that
        Shape.rotate(self,deg)                           #Get rotation matrix to perform the rotate operation
        step1=np.matmul(self.T_t,self.T_r)
        Shape.translate(self,-rx,-ry)                    #Translate back the point of rotation so translate matrix for that
        final_rot_matrix=np.matmul(step1,self.T_t)       #Get final rotate matrix by the formula final R= TRT
        ans=np.matmul(final_rot_matrix,self.matrix.T)    #Perform rotation and get final coordinates by multiplying final rotation matrix with matrix of coordinates
        final_coord_x=[]
        final_coord_y=[]
        for_ones=[]
        for i in range(len(ans[0])):
            final_coord_x.append(round(ans[0][i],2))    #Forming lists for final coordinates
            for_ones.append(1)
        for i in range(len(ans[1])):
            final_coord_y.append(round(ans[1][i],2))
        temp_matrix=np.array([final_coord_x,final_coord_y,for_ones])
        self.old_matrix=self.matrix                                   #Replacing previous coordinates with existing ones and then replacing current coordinates with the changed ones
        self.matrix=temp_matrix.T
        return(np.array(final_coord_x),np.array(final_coord_y))       #Returning final coordinates in the given format
        
    

    def plot(self):
        '''
        Function to plot the polygon
    
        This function should plot both the initial and the transformed polygon
    
        This function should use the parent's class plot method as well
    
        This function does not take any input
    
        This function does not return anything
        '''
        x_coords=[]
        y_coords=[]
        for i in range (len(self.matrix)):                 #Form a list of x coordinates of Polygon
            x_coords.append(self.matrix[i][0])
        for i in range (len(self.matrix)):
            y_coords.append(self.matrix[i][1])             #Form a list of y coordinates of polygon
        closing_x=[x_coords[0],x_coords[len(x_coords)-1]]      #For closing the polygon need coordinates of first and last point
        closing_y=[y_coords[0],y_coords[len(y_coords)-1]]
        x__coords=[]
        y__coords=[]
        for i in range (len(self.old_matrix)):
            x__coords.append(self.old_matrix[i][0])         #Forming a list of old x coordinates
        for i in range (len(self.old_matrix)):
            y__coords.append(self.old_matrix[i][1])         #Forming a list of old y coordinates
        closing__x=[x__coords[0],x__coords[len(x__coords)-1]]        #Similarly for joining first and last point
        closing__y=[y__coords[0],y__coords[len(y__coords)-1]]
        find_max_x=[]
        find_max_y=[]
        find_max_x.extend(x_coords)
        find_max_x.extend(x__coords)        #For setting the dimension of graphs find maximum x coordinate among the combines list of old and current coordinates for x and y separately
        find_max_y.extend(y_coords)
        find_max_y.extend(y__coords)
        for i in range(len(find_max_x)):
            if find_max_x[i]<0:
                find_max_x[i]*=-1
        for i in range(len(find_max_y)):
            if find_max_y[i]<0:
                find_max_y[i]*=-1

        x_dim=(max((find_max_x)))
        y_dim=(max((find_max_y)))
        plt.plot(x_coords,y_coords,color="blue")      #Plot current x and y coordinates
        plt.plot(closing_x,closing_y,color="blue")   #Join last and first coordinates
        plt.plot()
        plt.plot(x__coords,y__coords,color="blue",linestyle="dashed")    #Plot old x and y coordinates using a dashed line
        plt.plot(closing__x,closing__y,color="blue",linestyle="dashed")  #Join last and first coordinate
        plt.plot()
        Shape.plot(self,x_dim,y_dim)     #For plotting the basic graph on which Polygon would be drawn
        plt.show()
        


class Circle(Shape):
    '''
    Object of class Circle should be created when shape type is 'circle'
    '''
    def __init__(self, x=0, y=0, radius=5):
        '''
        Initializations here
        '''
        self.x=x
        self.y=y                        #Attributes for storing current center coordinates and radius and old center coordinates and radius
        self.radius=radius
        self.x_old=x
        self.y_old=y 
        self.radius_old=radius
        super().__init__()              #Inherit attributes from class Shape

    
    def translate(self, dx, dy=None):
        '''
        Function to translate the circle
    
        This function takes 2 arguments: dx and dy (dy is optional).
    
        This function returns the final coordinates and the radius
        '''
        if(dy==None):
            dy=dx
        circ_details = np.array([[self.x,self.y,1]])
        transpose=circ_details.T
        Shape.translate(self,dx,dy)                 #Get translate matrix for performing translation
        new_coord = np.matmul(self.T_t,transpose)   #Get new coordinates by multiplying translate matrix with the matrix of coordinates of center
        self.radius_old=self.radius                 #In translate radius remains same
        self.x_old=self.x
        self.y_old=self.y                           #Replacing old center coordinates with current ones and then replacing current ones with new ones
        self.x=round(new_coord[0][0],2)
        self.y=round(new_coord[1][0],2)
        ans=np.array([self.x,self.y,self.radius])
        return ans
        
 
        
    def scale(self, sx):
        '''
        Function to scale the circle
    
        This function takes 1 argument: sx
    
        This function returns the final coordinates and the radius
        '''
        Shape.scale(self,sx,1)                                          #Get scale matric for performing scaling
        new_coord=np.matmul(self.T_s,np.array([[self.radius,1,1]]).T)   #Get new coordinates by multiplying scaling matrix with matrix having radius of the circle
        self.radius_old=self.radius                                     #Replacing old radius with current one and current radius with new one
        self.radius=round(new_coord[0][0],2)
        ans=np.array([self.x,self.y,self.radius])
        return ans
 
    
    def rotate(self, deg, rx = 0, ry = 0):
        '''
        Function to rotate the circle
    
        This function takes 3 arguments: deg, rx(optional), ry(optional). Default rx and ry = 0. (Rotate about origin)
    
        This function returns the final coordinates and the radius
        '''
        Shape.translate(self,rx,ry)                         #Translate the point of rotation to origin so translate matrix for that
        Shape.rotate(self,deg)                              #Get rotation matrix to perform the rotate operation
        step1=np.matmul(self.T_t,self.T_r)
        Shape.translate(self,-rx,-ry)                      #Translate back the point of rotation so translate matrix for that
        final_rot_matrix=np.matmul(step1,self.T_t)         #Get final rotate matrix by the formula final R= TRT
        ans=np.matmul(final_rot_matrix,np.array([[self.x,self.y,1]]).T)     #Perform rotation and get final coordinates by multiplying final rotation matrix with matrix of coordinates of center of the circle
        self.x_old=self.x
        self.y_old=self.y                                           #Replacing old center coordinates with current ones and then replacing current ones with new ones
        self.radius_old=self.radius                                 #In rotate radius remains same
        self.x=round(ans[0][0],2)
        self.y=round(ans[1][0],2)
        final_ans=np.array([self.x,self.y,self.radius])
        return final_ans
 
    
    def plot(self):
        '''
        Function to plot the circle
    
        This function should plot both the initial and the transformed circle
    
        This function should use the parent's class plot method as well
    
        This function does not take any input
    
        This function does not return anything
        '''
        c1=plt.Circle((self.x,self.y),self.radius,fill=False,color='blue')                        #Creating an object Circle using matplotlib with center coordinates of the circle and radius specified
        c2=plt.Circle((self.x_old,self.y_old),self.radius_old,fill=False,color='blue',linestyle='--')  #Doing the same for circle with old coordinates and radius
        fig, temp = plt.subplots()                           #Create a figure to be plotted
        temp.set_aspect(1)
        temp.add_patch(c1)                                   #Adding patches of the circle on the graph in order to plot them           
        temp.add_patch(c2)
        lst1=[(abs(self.x)+abs(self.radius)),(abs(self.x_old)+abs(self.radius_old))]       #Setting dimensions for graph by finding the numerically greatest coordinate to be plotted on the graph
        lst2=[(abs(self.y)+abs(self.radius)),(abs(self.y_old)+abs(self.radius_old))]
        x_dim=abs(max(lst1))
        y_dim=abs(max(lst2))
        Shape.plot(self,x_dim,y_dim)
        

if __name__ == "__main__":
    '''
    Add menu here as mentioned in the sample output section of the assignment document.
    '''
   
def print_coords_polygon(obj):
    final_coord_x=[]                                   #Function to print polygon coordinates in the desired order
    final_coord_y=[]
    for i in range(0,len(obj.matrix)):
        final_coord_x.append(obj.matrix[i][0])
    for i in range (0,len(obj.matrix)):
        final_coord_y.append(obj.matrix[i][1])
    w= (np.array(final_coord_x),np.array(final_coord_y))
    x_c=w[0]
    y_c=w[1]
    final=[]
    final.extend(x_c)
    final.extend(y_c)
    for q in final:
        print(q,end=' ')
    print("\n")

def print_coords_circle(self):
    lst=[]
    lst.append(self.x)
    lst.append(self.y)                              #Function to print circle center coordinates and radius in the desired order
    lst.append(self.radius)
    for i in lst:
        print(i,end=" ")
    print("\n")

''' Taken inputs for verbose, number of test cases and then taken input for type of Shape. Formed the matrix of coordinates in case of polygons
and taken inputs for center coordinates and radius for circles. Taken in queries and then accordingly executed the functions and shown the previous and 
final coordinates 
  '''
verbose =int(input("verbose? 1 to plot, 0 otherwise : "))
test_cases=int(input("Enter the number of test cases : "))
for k in range(1,test_cases+1):
    type_of_shape=int(input("Enter type of shape (0 for polygon/ 1 for circle) :"))
    if(type_of_shape==0):
        n=int(input("Enter the number of sides : "))
        form_A=[]
        for i in range(1,n+1):
            x, y = [float(x) for x in input("Enter (x"+str(i)+",y"+str(i)+") : ").split()] 
            coord=[]
            coord.append(x)
            coord.append(y)
            coord.append(1)                                               
            form_A.append(coord)
        A=np.array(form_A)
        obj=Polygon(A)
        num_of_queries=int(input("Enter the number of queries : "))
        for j in range(1,num_of_queries+1):
            print("\nEnter query :")
            print("1) R deg (rx) (ry)")
            print("2) T dx (dy)")
            print("3) S sx (sy)")
            print("4) P")
            input_for_query=list(map(str,input().split()))
            if(input_for_query[0].lower()=='t'):
                (print_coords_polygon(obj))
                if(len(input_for_query)==2):
                    x=(obj.translate(float(input_for_query[1])))
                else:
                    x=(obj.translate(float(input_for_query[1]),float(input_for_query[2])))
                x_c=x[0]
                y_c=x[1]
                final=[]
                final.extend(x_c)
                final.extend(y_c)
                for q in final:
                    print(q,end=' ')



                if(verbose==1):
                    obj.plot()


            elif(input_for_query[0].lower()=='s'):
                (print_coords_polygon(obj))
                if(len(input_for_query)==2):
                    x=(obj.scale(float(input_for_query[1])))
                else:
                    x=(obj.scale(float(input_for_query[1]),float(input_for_query[2])))
                
                x_c=x[0]
                y_c=x[1]
                final=[]
                final.extend(x_c)
                final.extend(y_c)
                for q in final:
                    print(q,end=' ')
                if(verbose==1):
                    obj.plot()


            elif(input_for_query[0].lower()=='r'):
                (print_coords_polygon(obj))
                if(len(input_for_query)==2):
                    x=(obj.rotate(float(input_for_query[1])))

                elif(len(input_for_query)==3):
                    x=(obj.rotate(float(input_for_query[1]),float(input_for_query[2]),float(input_for_query[2])))
                else:
                    x=(obj.rotate(float(input_for_query[1]),float(input_for_query[2]),float(input_for_query[3])))
                
                x_c=x[0]
                y_c=x[1]
                final=[]
                final.extend(x_c)
                final.extend(y_c)
                for q in final:
                    print(q,end=' ')
                if(verbose==1):
                    obj.plot()


            elif(input_for_query[0].lower()=='p'):
                print(print_coords_polygon(obj))
                obj.plot()

            print("\n")

    elif(type_of_shape==1):
        x, y, r = [float(x) for x in input("Enter center coordinates (x,y) and radius (space - separated) : ").split()]
        obj=Circle(x,y,r)
        num_of_queries=int(input("Enter the number of queries : "))
        for j in range(1,num_of_queries+1):
            print("\nEnter query :")
            print("1) R deg (rx) (ry)")
            print("2) T dx (dy)")
            print("3) S sx (sy)")
            print("4) P")
            input_for_query=list(map(str,input().split()))
            if(input_for_query[0].lower()=='t'):
                (print_coords_circle(obj))
                if(len(input_for_query)==2):
                    x=(obj.translate(float(input_for_query[1])))
                else:
                    x=(obj.translate(float(input_for_query[1]),float(input_for_query[2])))
                x_c=x[0]
                y_c=x[1]
                r_c=x[2]
                final=[]
                final.append(x_c)
                final.append(y_c)
                final.append(r_c)
                for q in final:
                    print(q,end=' ')

                if(verbose==1):
                    obj.plot()

            elif(input_for_query[0].lower()=='s'):
                (print_coords_circle(obj))
                x=obj.scale(float(input_for_query[1]))
                x_c=x[0]
                y_c=x[1]
                r_c=x[2]
                final=[]
                final.append(x_c)
                final.append(y_c)
                final.append(r_c)
                for q in final:
                    print(q,end=' ')

                if(verbose==1):
                    obj.plot()

            elif(input_for_query[0].lower()=='r'):
                (print_coords_circle(obj))
                if(len(input_for_query)==2):
                    x=(obj.rotate(float(input_for_query[1])))
                elif(len(input_for_query)==3):
                    x=(obj.rotate(float(input_for_query[1]),float(input_for_query[2]),float(input_for_query[2])))
                else:
                    x=(obj.rotate(float(input_for_query[1]),float(input_for_query[2]),float(input_for_query[3])))
                x_c=x[0]
                y_c=x[1]
                r_c=x[2]
                final=[]
                final.append(x_c)
                final.append(y_c)
                final.append(r_c)
                for q in final:
                    print(q,end=' ')

                if(verbose==1):
                    obj.plot()

            elif(input_for_query[0].lower()=='p'):
                print(print_coords_circle(obj))
                obj.plot()

            print("\n")











